<?php
include 'config.php';

// Get all products
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $query = "SELECT * FROM barang";
    $result = mysqli_query($conn, $query);
    $barang = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $barang[] = $row;
    }
    
    echo json_encode(["success" => true, "data" => $barang]);
}

// Add new product
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    
    $nama_barang = $data->nama_barang;
    $jenis = $data->jenis;
    $stok = $data->stok;
    $harga_jual = $data->harga_jual;

    $query = "INSERT INTO barang (nama_barang, jenis, stok, harga_jual) 
              VALUES ('$nama_barang', '$jenis', $stok, $harga_jual)";

    if (mysqli_query($conn, $query)) {
        echo json_encode(["success" => true, "message" => "Product added successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to add product"]);
    }
}

// Update product
if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    $data = json_decode(file_get_contents("php://input"));
    
    $id = $data->id;
    $nama_barang = $data->nama_barang;
    $jenis = $data->jenis;
    $stok = $data->stok;
    $harga_jual = $data->harga_jual;

    $query = "UPDATE barang SET 
              nama_barang = '$nama_barang',
              jenis = '$jenis',
              stok = $stok,
              harga_jual = $harga_jual
              WHERE id = $id";

    if (mysqli_query($conn, $query)) {
        echo json_encode(["success" => true, "message" => "Product updated successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to update product"]);
    }
}

// Delete product
if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    $data = json_decode(file_get_contents("php://input"));
    $id = $data->id;

    $query = "DELETE FROM barang WHERE id = $id";

    if (mysqli_query($conn, $query)) {
        echo json_encode(["success" => true, "message" => "Product deleted successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to delete product"]);
    }
}
?>