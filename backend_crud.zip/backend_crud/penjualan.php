<?php
include 'config.php';

// Get all sales
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $query = "SELECT p.*, b.nama_barang 
              FROM penjualan p 
              JOIN barang b ON p.id_barang = b.id";
    $result = mysqli_query($conn, $query);
    $penjualan = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $penjualan[] = $row;
    }
    
    echo json_encode(["success" => true, "data" => $penjualan]);
}

// Add new sale
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    
    $id_barang = $data->id_barang;
    $jumlah = $data->jumlah;
    $harga_jual = $data->harga_jual;

    // Check stock availability
    $check_stock = "SELECT stok FROM barang WHERE id = $id_barang";
    $stock_result = mysqli_query($conn, $check_stock);
    $stock_data = mysqli_fetch_assoc($stock_result);
    
    if ($stock_data['stok'] >= $jumlah) {
        $query = "INSERT INTO penjualan (id_barang, jumlah, harga_jual) 
                  VALUES ($id_barang, $jumlah, $harga_jual)";
        
        if (mysqli_query($conn, $query)) {
            // Update stock
            $update_stock = "UPDATE barang 
                           SET stok = stok - $jumlah 
                           WHERE id = $id_barang";
            mysqli_query($conn, $update_stock);
            
            echo json_encode(["success" => true, "message" => "Sale recorded successfully"]);
        } else {
            echo json_encode(["success" => false, "message" => "Failed to record sale"]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "Insufficient stock"]);
    }
}
?>