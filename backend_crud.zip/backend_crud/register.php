<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    
    $nama_lengkap = $data->nama_lengkap;
    $username = $data->username;
    $password = password_hash($data->password, PASSWORD_DEFAULT);
    $alamat = $data->alamat;
    $nohp = $data->nohp;

    $query = "INSERT INTO users (nama_lengkap, username, password, alamat, nohp) 
              VALUES ('$nama_lengkap', '$username', '$password', '$alamat', '$nohp')";

    if (mysqli_query($conn, $query)) {
        echo json_encode(["success" => true, "message" => "Registration successful"]);
    } else {
        echo json_encode(["success" => false, "message" => "Registration failed"]);
    }
}
?>